# H-DECISION-REPLICATION formal chunk

Status: failed
Failure: AssertionError()
Accepted complete pairs: 63
Artifacts: /home/select766/shogi/train-nnue/.research-loop/experiments/decision-replication-formal-floodgate2025-chunk001/attempt-001/artifacts/execution-20260920T203122-199999
Logs: /tmp/decision-formal-execution-20260920T203122-199999-*.log
No interim strength decision. All 61 chunks are required for the single primary analysis.
Failure/timeout requires review and explicit retry; incomplete pairs are not scored.

Shell exit: 1
Log: /tmp/decision-formal-chunk001-20260920T113119-199882.log
Progress: /home/select766/shogi/train-nnue/.research-loop/experiments/decision-replication-formal-floodgate2025-chunk001/attempt-001/artifacts/progress-20260920T113119-199882.txt
