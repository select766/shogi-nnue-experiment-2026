# H-DECISION-REPLICATION: formal chunk001

2026-09-20 prepare。対局未実行。今回jobのreplan_history/human_decisionsは空。
旧manifestの全祖先分離要求は現行autonomy方針で置換済み。cost16 reviewと事前登録を継承し、
同じ不足を再要求しない。新仮説なし。H-DECISION-REPLICATIONを検証中へ更新する。

## 仮説・対照

seed42 decision-aligned weight005_from_m0 checkpoint9既存releaseが、task-only
control_from_m0 checkpoint9既存releaseを上回るか。再学習・再export・モデル再選抜なし。
事前登録: docs/research/experiments/decision-replication-floodgate2025-20260920.md。
費用結果: docs/research/results/decision-replication-cost-floodgate2025-20260920/README.md。
同結果chunks.jsonのchunk=1、正式openings10000.jsonlの1〜166行、166ペア332局のみ。
10,000ペア全体は166×60+40の61 chunk。cost8、reserve、旧14,000局、日次は合算しない。

## 固定条件

protocol.jsonはcost review保存版と完全一致。qualified private engine SHA256:
5f7591ce03b55cf8016871f0ab7f11b4e2bd63be27b7d5b80c85a060ffeebc65。
candidate backbone: 823f461d19a7e3c1af0ddfaea5d41b56085f936c7b6f37daa81220f9bdf1dfe4。
control backbone: 88b792cc8019b654a8ccc6d5c439e229a885d6dcc7af47b5226e25ef133bfc0b。
両head.bin: eb12f9b6086c55ab2b96a177429b7409fe63c4b06c63cd2389ddbe07fcb1171f。
全固定入力・実装hashはinput-manifest.json。実ロードlibraryはcostと同一hashを要求。

100,000 nodes/着手、Threads=1、USI_Hash=16、MultiPV=1、Ponder=false、no_book、
ResignValue=99999、ClearTTOnDynamicWeights=true、LogDynamicWeightCache=true、
GenerateAllLegalMoves=false。他defaultsは固定binaryからadvertised一覧を保存。
ファイル順、候補先手→候補後手。盤面は反転せず、プレイヤーだけ交換。
同一実行内の2エンジンprocessを維持し、毎局両engineへisready→usinewgame。
元initial_sfen＋history_usiを合法再生し、全探索へ元履歴＋追加着手を送信。
探索ごとにblend/clear=1、実nodes、bestmoveの通信を照合する。
4回反復・連続王手負け・詰み/合法手なし・resign・合法入玉を裁定、追加512手で引分。
反復・詰みは512手制限に優先。元履歴を反復判定へ含める。

## データ分離・限界

data-catalog.jsonはconfigs/research_data.jsonのsnapshot。
curated manifest: 31a8d11f675285ecb8ff8ecbeacf6838f3a178412ba605836b98617d85d5f2f3。
match-plan manifest: 7e95ae6ba79537616c7554bef94dfeec1d51399cc453aa216f8f464dda92a7af。
formal10000: ecf70e1cec54e5274f2581c21cf66657110a25e5d91902f4e1b2c21a5bed654d。
双方元rating>=3500、1棋譜1局面、match専用split。development/selection/testとは棋譜分離。
cost/formal/reserveの棋譜・盤面非重複と今回166局面の元履歴を再検査する。
既知24,995旧局面の除外を利用。全pretraining祖先・全教師の分離、checkpointからの
再export一致は未確認。固定release・seed42・履歴clearありに限定し、完全独立とは呼ばない。
理想教師・追加データ取得は開始条件にしない。日次series/championを変更しない。

## 成功・棄却・未確定

chunkの運用成功: 固定166ペア全完了、hash・設定・元履歴・合法手・終局・score・
全USI送受信と毎局reset・各探索clearを独立に再監査できること。
これは棋力仮説の支持ではない。途中chunkでElo/区間/主判定を計算しない。
全61 chunk・20,000局の完全ペア監査後に一度だけ事前登録どおり主判定する。
X_i=(候補先手score+候補後手score)/2、勝1/分0.5/負0。
pの95%区間=p±1.959963984540054*sd(X)/sqrt(10000)。下端>0.5なら支持、
上端<0.5なら当該固定条件の正改善を棄却、0.5を含めば未確定。同等性とはしない。
補助Elo=400log10(p/(1-p))、実用目安+5 Elo、上位対局者相関未補正なども元事前登録に従う。

## 費用・停止・retry

CPUのみ、2 process・逐次1対局。GPU不要。cost平均36.918秒/ペアから約6,128秒、
最遅×2の計画126.460秒/ペアから約20,992秒（起動・検査別）。保証ではない。
本体全体上限21,600秒。shellの検査300秒+入力60秒+計算21,000秒+kill猶予30秒+
最終監査60秒=最大21,450秒、管理側21,600秒。計算内部期限20,400秒には監査も含む。
内部期限・外部timeout・通信障害・不正hash/履歴/合法性/証跡で停止し、未完は得点にしない。
途中成績による成功・無益停止、局面差し替え、条件緩和は禁止。

自動再試行なし。review後の明示retry時のみ同じattemptの固定ID markerを再監査して
完全ペアを再利用。markerのない途中ペアは両局とも新processで再実行し旧ディレクトリを保持。
入力・protocol・実装hash不一致、完成markerの破損は混合せず停止・reviewで再計画。
時間不足はreplan、20,000局未達は主判定未確定。人間への標本補充要求はしない。
正常完了reviewはchunk002（167〜332行）を固定条件で提案する。
