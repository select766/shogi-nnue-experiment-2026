# formal-floodgate2025-chunk001 / attempt-001 引継ぎ

prepare完了。run.sh、実engine、学習、buildは一度も起動していない。
H-DECISION-REPLICATIONは検証中・優先順位1。新仮説なし。障害・人間待ちなし。
job.jsonのreplan_history/human_decisionsは空。旧manifest未実行終了とcost16 reviewを確認し、
完全祖先分離の再要求をせず、既存最終データと同一モデル・条件で準備した。

## 起動契約

RUN_DIR=/home/select766/shogi/train-nnue/.research-loop/experiments/decision-replication-formal-floodgate2025-chunk001/attempt-001
run.shはrootへcd、set -euo pipefail。外側がprepare終了後にsandbox外で実行する。
CPU推論専用。GPU不要・fallbackなし。API/Codex、daemon、background起動なし。
全体timeout_seconds=21600。shell内の上限合計21450秒、計算内部20400秒。
入力検査/最終監査が各60秒を超えても失敗としてreviewへ渡し、自動再実行しない。
大量stdoutとUSI生ログは/tmp/decision-formal-*.log、失敗時もEXIT trapで要約へexit/logを残す。
主判定・Eloをchunk単体で計算しない。正常reviewは固定chunk002を次ジョブへ提案する。

## 実装・入力

src/train_nnue/decision_replication_formal.py:
- --check-only: input-manifest全hash、cost/formal/reserveの件数と分離、chunk登録一致、
  今回166行の全履歴再生、protocolとcost保存版一致。engineを起動しない。
- 本体: 固定ファイル順・候補先手→後手。cost時と同じ2 processを実行内で維持する。
  各gameのisready→usinewgameと元棋譜全履歴送信は既存play_gameをそのまま利用。
  起動時USI設定・handshakeを監査してgzip保存し、実ロードlibraryをcostのhashと比較する。
- 各局finallyでgame/recordsを保存、各ペアfinallyで当該範囲のUSIログをgzip保存。
  完全ペアの合法再生・通信・終局・score監査後だけ原子的な固定ID markerを作成。
- --audit-only: engineなしで今回166のmarkerをすべて再監査し、入力hashも再検査する。

src/train_nnue/decision_replication_audit.py:
review済みcost auditをペア単位へ一般化。元履歴、探索前終局条件、合法全着手、
4回反復/連続王手、入玉、512追加手、候補score、送信position/go、全探索応答、
clear/blend各1件、nodes、bestmove、毎局reset/readyok、library hashを照合する。
ログは初期handshakeを除いた各ペアの実通信sliceであり、合成したUSI証跡ではない。
Python最適化でassertを無効化した場合は明示拒否する。

input-manifest.jsonはcost時の31 hashを全て維持して、新runner/auditor/tests、
chunk、protocol、library baseline、run.sh/plan/handoff等を追加固定したもの。
protocol.jsonはcost review版と同一。chunk.jsonは固定chunks.jsonの第1要素。
libraries.jsonはcostの実ロードlibrary一覧のsnapshot。
データ・モデルの正確なhashと分離・主張範囲はplan.mdとinput-manifest.jsonを参照。
checkpoint再export一致・全祖先分離は未確認。固定releaseの比較に限定する。

## 保存先・review

artifacts/latest.json → 今回のexecution-日時-PIDディレクトリ。
execution内: manifest.json（git/submodule/runtime/入力hash）、identity.json、
engine-*.json、maps-*.txt、initialization-*.log.gz、progress.json、accepted.json、summary.json。
各pair-00001..00166ディレクトリ: openings/protocol、engine metadata、libraries、
game-001.json/game-002.json、records.json、candidate.log.gz/control.log.gz。
records内opening_indexはペア内0、pair_idは正式ファイルの1始まり行番号、game_hashは原棋譜ID。
候補色0→1。局の一意IDは(pair_id,candidate_color)。部分局にはcomplete=false/errorを残す。

artifacts直下pair-NNNNN.jsonは完全ペアの受理marker。
directoryは元execution内ペアを指し、identityは入力manifest/protocol/chunk/libraryのhash。
accepted.jsonは今回実行中の進捗、summary.jsonのpairsは再利用分を含む全受理一覧。
result-summary.mdは64KiB未満で成否/完了数/ログ/詳細成果物を案内する。
Pythonがcompleteでもshell最終監査の非zero/timeoutは成功としない。
reviewはexecution.json、shell exit、summary、--audit-onlyの結果を合わせて判断する。
初期handshake、終了quitの生ログも確認できる。正常ペアの監査は/tmp消失後もgzipから可能。

## 明示retry時の挙動

自動retryしない。管理側で明示retry executeしたときだけ、同じattemptのmarkerを読み、
identity一致と完全ペア再監査に合格した固定IDを再利用する（学習checkpoint再開ではない）。
markerなしの途中ペアは、旧executionディレクトリを隔離保持したまま、両局を新processで
最初から実施する。SIGTERMは例外へ変換してfinally保存、SIGKILLでは既存保存分だけ残る。
完成markerの破損・不一致は自動無視/再計算せず停止。reviewが影響範囲を判断する。
別attemptからの成果物自動探索/移植はしない。新prepareへ移る場合、reviewが版一致と
完全ペアを監査し明示的な移行計画を作る。違う実装/条件の結果を無条件に混合しない。
旧データ削除・state.json編集なし。

## 検査・既知の制約

32件のmock/合成回帰検査。全棋譜実行、部分ペア失敗保存、identity不一致拒否、
完成ペア再監査/再利用、元履歴を跨ぐ反復、既存qualificationを含む。
追加で保存済みcost全8ペア16局1,273探索を新auditorで再監査し、score/reset/clear/positionの
4種類の破損が拒否されることを確認。新たな対局を実施したものではない。
check_saved_cost.pyは直接ファイル起動だとscripts importで失敗したため、既存reviewと同じ
wrapperの -c + runpy.run_path で解消。通常runnerは -m 入口で実行し、この問題はない。
prepare-checks.txtに検査結果を保存。run.shはbash -nのみ、実行していない。

cost8からの時間外挿は保証ではなく、内部期限で332局に届かない可能性はある。
既存AuditedEngineの応答上限120秒、古い期限エラー文の50-minuteは表示のみで、実際は
本runnerの20400秒deadlineを渡す。自由探索の連続王手/入玉/512手はcostで観測されず、
合成検査の範囲を越えて実測保証しない。全正式完了後の主判定は別の最終reviewで行う。

## 変更ファイル

- src/train_nnue/decision_replication_formal.py（新規）
- src/train_nnue/decision_replication_audit.py（新規）
- tests/test_decision_replication_formal.py（新規）
- docs/research/hypotheses.md（対象を検証中へ）
- 本attempt: plan.md、handoff.md、run.sh、data-catalog.json、protocol.json、chunk.json、
  libraries.json、input-manifest.json、check_saved_cost.py、prepare-checks.txt。

実装と台帳は計算後reviewで結果文書・最終判定とともに検査/コミットする。
prepareを実験完了とは扱わない。サブモジュールやchampionは変更していない。
